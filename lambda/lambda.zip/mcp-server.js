// mcp-server.ts
import { readFileSync } from "fs";
import { join } from "path";
function parseDaemonMd(content) {
  const sections = {};
  const lines = content.split(`
`);
  let currentSection = "";
  let currentContent = [];
  for (const line of lines) {
    if (line.startsWith("[") && line.endsWith("]")) {
      if (currentSection) {
        sections[currentSection] = currentContent.join(`
`).trim();
      }
      currentSection = line.slice(1, -1).toLowerCase();
      currentContent = [];
    } else if (currentSection) {
      currentContent.push(line);
    }
  }
  if (currentSection) {
    sections[currentSection] = currentContent.join(`
`).trim();
  }
  const data = {
    about: sections.about,
    mission: sections.mission,
    telos: sections.telos,
    current_location: sections.current_location,
    last_updated: new Date().toISOString()
  };
  const listSections = [
    "preferences",
    "daily_routine",
    "favorite_books",
    "favorite_movies",
    "favorite_podcasts",
    "predictions"
  ];
  for (const section of listSections) {
    if (sections[section]) {
      const items = sections[section].split(`
`).filter((line) => line.trim().startsWith("-")).map((line) => line.trim().slice(1).trim());
      if (items.length > 0) {
        data[section] = items;
      }
    }
  }
  return data;
}
function loadDaemonData() {
  try {
    const possiblePaths = [
      process.env.DAEMON_MD_PATH,
      "/var/task/daemon.md",
      join(process.cwd(), "daemon.md"),
      "./daemon.md"
    ].filter(Boolean);
    let content = null;
    for (const daemonMdPath of possiblePaths) {
      try {
        content = readFileSync(daemonMdPath, "utf-8");
        console.log(`Successfully loaded daemon.md from: ${daemonMdPath}`);
        break;
      } catch (err) {
        continue;
      }
    }
    if (!content) {
      throw new Error("Could not find daemon.md in any expected location");
    }
    return parseDaemonMd(content);
  } catch (error) {
    console.error("Failed to load daemon.md:", error);
    return { last_updated: new Date().toISOString() };
  }
}
var tools = [
  {
    name: "get_about",
    description: "Get information about Rick Rezinas",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: "get_mission",
    description: "Get Rick's mission statement",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: "get_telos",
    description: "Get Rick's TELOS framework (Problems, Missions, Goals)",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: "get_current_location",
    description: "Get Rick's current location",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: "get_preferences",
    description: "Get Rick's preferences and work style",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: "get_daily_routine",
    description: "Get Rick's daily routine",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: "get_favorite_books",
    description: "Get Rick's favorite books",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: "get_favorite_movies",
    description: "Get Rick's favorite movies",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: "get_favorite_podcasts",
    description: "Get Rick's favorite podcasts",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: "get_predictions",
    description: "Get Rick's predictions about the future",
    inputSchema: { type: "object", properties: {} }
  },
  {
    name: "get_all",
    description: "Get all daemon data",
    inputSchema: { type: "object", properties: {} }
  }
];
function handleToolCall(toolName, data) {
  const fieldMap = {
    get_about: "about",
    get_mission: "mission",
    get_telos: "telos",
    get_current_location: "current_location",
    get_preferences: "preferences",
    get_daily_routine: "daily_routine",
    get_favorite_books: "favorite_books",
    get_favorite_movies: "favorite_movies",
    get_favorite_podcasts: "favorite_podcasts",
    get_predictions: "predictions"
  };
  if (toolName === "get_all") {
    return JSON.stringify(data, null, 2);
  }
  const field = fieldMap[toolName];
  if (field && data[field]) {
    const value = data[field];
    return Array.isArray(value) ? value.join(`
`) : value;
  }
  return "No data available";
}
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      },
      body: ""
    };
  }
  try {
    const daemonData = loadDaemonData();
    const body = JSON.parse(event.body || "{}");
    const { jsonrpc, method, params, id } = body;
    if (method === "tools/list") {
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({
          jsonrpc: "2.0",
          result: { tools },
          id
        })
      };
    }
    if (method === "tools/call") {
      const toolName = params?.name;
      const result = handleToolCall(toolName, daemonData);
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({
          jsonrpc: "2.0",
          result: {
            content: [{ type: "text", text: result }]
          },
          id
        })
      };
    }
    return {
      statusCode: 400,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        error: { code: -32601, message: "Method not found" },
        id
      })
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        error: { code: -32603, message: "Internal error" },
        id: null
      })
    };
  }
};
export {
  handler
};
